FITNESS TRACKER ANALYSIS PROJECT README

This is the documentation for our Engineering Applications Project: Option 1 (Fitness Tracker Analysis).

1. TEAM ROLES & WHO DID WHAT

Our team of three covered all the required roles:
Data Manager: Vova Nelen
Job: Created and organized all the raw data files (`.csv` and `.txt`), set up the folders, and handled all file loading/saving in the code.
Algorithm Developer: Ya'ir Sasson
Job: Wrote the main analysis script (`FitnessAnalyzer.m`), figured out the heart rate zone math, and calculated all the final summary statistics.
Visualization Specialist: Lucas Melendez
Job: Designed, formatted, and generated all the final plots (line charts, bar charts, scatter plots, and the dashboard).

2. PROJECT FOLDER STRUCTURE

We followed the required structure. You can find everything in these folders:

* **Data/Athletes/**: Contains the three raw data CSV files and the `athlete_profiles.txt` metadata file.
* **Scripts/**: Contains our main MATLAB code, `FitnessAnalyzer.m`.
* **Results/**: This folder is automatically created by the script. It holds all the final output:
    * `hr_trend_line.png`
    * `intensity_duration_scatter.png`
    * `zone_minutes_bar.png`
    * `summary_dashboard.png`
    * [NOTE: Missing plots will be added here to meet the 5-figure requirement.]**
    * **`summary_stats.csv`** (The table of final comparisons)
    * **`project_workspace.mat`** (The saved MATLAB workspace)

3. DATA FORMATS

All fitness data is in CSV format. Each athlete file contains 21 days of data with the following columns:

* Day:** The day number (1 to 21).
* ExerciseType: What the athlete did (e.g., Running, Cycling, Rest).
* PreWorkoutHR: Heart rate right before the workout (bpm).
* PostWorkoutHR: Heart rate right after the workout (bpm).
* Duration: Workout length in minutes.
* Intensity: Self-rated effort on a 1-10 scale.

The `athlete_profiles.txt` file is just a quick reference to the fitness level of each athlete (Beginner, Intermediate, Advanced).

4. KEY FINDINGS & WORKSPACE

Key Findings:
Our analysis shows clear differences across the three fitness levels:

Advanced Athlete: Consistently had the lowest resting heart rate, the longest workouts, and the highest duration in the Vigorous HR zone.
Beginner Athlete: Had a higher resting heart rate, shorter workouts, and spent most of their time in the Light/Moderate zones.
Recovery: The Advanced athlete showed the most efficient recovery (smallest difference between Post and Pre HR).

Workspace Documentation:
Our script uses the `save` function to create a file called **`project_workspace.mat`**. This file captures all the variables created during the run, including:

* `AthleteData`: A cell array holding the final, processed data tables for all three athletes.
* `SummaryTable`: The final comparative table of all performance metrics.
* `all_zone_minutes`: The matrix used to generate the heart rate zone bar chart.