FITNESS TRACKER ANALYSIS PROJECT README

This is the documentation for our Engineering Applications Project: Option 1 (Fitness Tracker Analysis).

1. TEAM ROLES & WHO DID WHAT

Our team of three covered all the required roles:
Data Manager: Vova Nelen
Job: Created and organized all the raw data files (`.csv` and `.txt`), set up the folders, and handled all file loading/saving in the code.
Algorithm Developer: Ya'ir Sasson
Job: Wrote the main analysis script (`FitnessAnalyzer.m`), figured out the heart rate zone math, and calculated all the final summary statistics.
Visualization Specialist: Lucas Melendez
Job: Designed, formatted, and generated all the final plots (line charts, bar charts, scatter plots, and the dashboard).

2. PROJECT FOLDER STRUCTURE

We followed the required structure. You can find everything in these folders:

* Data/Athletes/: Contains the three raw data CSV files and the `athlete_profiles.txt` metadata file[cite: 5].
* Scripts/: Contains our main MATLAB code, `FitnessAnalyzer.m`[cite: 6].
* Results/: This folder is automatically created by the script. It holds all the final output (5 figures and 2 data files):
    * `summary_stats.csv` (The final comparative statistics table)
    * `project_workspace.mat` (The saved MATLAB workspace)
    * `zone_minutes_bar.png` (Figure 1)
    * `hr_trend_line.png` (Figure 2)
    * `recovery_rate_bar.png` (Figure 3: Recovery Comparison)
    * `duration_distribution_hist.png` (Figure 4: Workout Distribution)
    * `summary_dashboard.png` (Figure 5: The 2x2 comparative dashboard)

3. DATA FORMATS

All fitness data is in CSV format. Each athlete file contains 21 days of data with the following columns:

* Day: The day number (1 to 21).
* ExerciseType: What the athlete did (e.g., Running, Cycling, Rest).
* PreWorkoutHR: Heart rate right before the workout (bpm).
* PostWorkoutHR: Heart rate right after the workout (bpm).
* Duration: Workout length in minutes.
* Intensity: Self-rated effort on a 1-10 scale.

The `athlete_profiles.txt` file is just a quick reference to the fitness level of each athlete (Beginner, Intermediate, Advanced).

4. CODE EXECUTION INSTRUCTIONS

To run the analysis and generate all required results:

1.  Open MATLAB
2.  In the MATLAB Current Folder pane, navigate to the 'Scripts' folder where the `FitnessAnalyzer.m` file is located.
3.  Ensure the necessary data files are in the `Data/Athletes` folder (as documented above).
4.  In the MATLAB Command Window, simply type the script name: `FitnessAnalyzer`
5.  Press Enter.

The script will automatically execute the analysis, generate all five figures, and save the output files (PNGs, CSV, and MAT workspace) into the `Results` folder.

5. KEY FINDINGS & WORKSPACE

Key Findings:
Our analysis shows clear differences across the three fitness levels:

Advanced Athlete: Consistently had the lowest resting heart rate, the longest workouts, and the highest duration in the Vigorous HR zone.
Beginner Athlete: Had a higher resting heart rate, shorter workouts, and spent most of their time in the Light/Moderate zones.
Recovery: The Advanced athlete showed the most efficient recovery (smallest difference between Post and Pre HR).

Workspace Documentation:
Our script uses the `save` function to create a file called **`project_workspace.mat`**. This file captures all the variables created during the run, including:

* `AthleteData`: A cell array holding the final, processed data tables for all three athletes.
* `SummaryTable`: The final comparative table of all performance metrics.
* `all_zone_minutes`: The matrix used to generate the heart rate zone bar chart.