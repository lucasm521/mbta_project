%==========================================================================
% FitnessAnalyzer.m
%
% PROJECT: Option 1: Fitness Tracker Analysis
% TEAM: Vova Nelen, Ya'ir Sasson, Lucas Melendez
% DATE: 11/24/2025
%
% PURPOSE: Loads fitness data from three athletes, calculates performance
% metrics (HR Zones, Recovery Rate, Consistency), and generates five
% comparative visualizations and a final summary dashboard.
%
% INPUTS:
%   - Data/Athletes/athlete1_beginner.csv
%   - Data/Athletes/athlete2_intermediate.csv
%   - Data/Athletes/athlete3_advanced.csv
%
% OUTPUTS:
%   - Results/project_workspace.mat (Saved variables)
%   - Results/summary_stats.csv (Final comparative table)
%   - 5 Required PNG plots (e.g., zone_minutes_bar.png, summary_dashboard.png)
%==========================================================================

%% 1. INITIAL SETUP AND DIRECTORY MANAGEMENT
clear; clc; close all;

PROJECT_ROOT = fileparts(mfilename('fullpath'));
DATA_FOLDER = fullfile(PROJECT_ROOT, '..', 'Data', 'Athletes');
RESULTS_FOLDER = fullfile(PROJECT_ROOT, '..', 'Results');

% Create the Results folder if it does not exist
if ~isfolder(RESULTS_FOLDER)
    mkdir(RESULTS_FOLDER);
end

ATHLETE_NAMES = {'Beginner', 'Intermediate', 'Advanced'};

%% 2. DATA LOADING
try
    disp('Loading data files from /Data/Athletes folder...');
    T_beginner = readtable(fullfile(DATA_FOLDER, 'athlete1_beginner.csv'));
    T_intermediate = readtable(fullfile(DATA_FOLDER, 'athlete2_intermediate.csv'));
    T_advanced = readtable(fullfile(DATA_FOLDER, 'athlete3_advanced.csv'));
    disp('Data loaded successfully.');
catch ME
    error('Could not load data files. Ensure files are in a folder named "Athletes" inside "Data": %s', ME.message);
end

AthleteData = {T_beginner, T_intermediate, T_advanced};

%% 3. VARIABLE INITIALIZATION
HR_ZONES = {'Resting', 'Light', 'Moderate', 'Vigorous'};
all_zone_minutes = zeros(length(HR_ZONES), length(AthleteData));

% Initialize the summary statistics table with all required columns
summary_stats = table('Size', [length(AthleteData), 7], ...
    'VariableTypes', {'double', 'double', 'double', 'double', 'double', 'double', 'double'}, ...
    'VariableNames', {'TotalWorkouts', 'TotalDuration', 'AvgDuration', 'AvgIntensity', 'StdDevIntensity', 'AvgPostHR', 'AvgRecoveryRate'}, ...
    'RowNames', ATHLETE_NAMES);

%% 4. CORE ALGORITHM & ANALYSIS LOOP
disp(' ');
disp('Starting core algorithm processing...');

for i = 1:length(AthleteData)
    T_raw = AthleteData{i};

    % Call helper function to add RecoveryRate and correct HRZone
    T_processed = process_athlete_data(T_raw);

    % Filter only for actual workouts (Duration > 0) for calculating averages
    T_workouts = T_processed(T_processed.Duration > 0, :);

    % Store the processed table back into the cell array
    AthleteData{i} = T_processed;

    % Sum Zone Minutes
    zone_minutes = zeros(1, length(HR_ZONES));
    for j = 1:length(HR_ZONES)
        zone = HR_ZONES{j};
        idx_zone = T_processed.HRZone == zone;
        zone_minutes(j) = sum(T_processed.Duration(idx_zone));
    end
    all_zone_minutes(:, i) = zone_minutes';

    % Calculate Summary Statistics
    summary_stats.TotalWorkouts(i) = height(T_workouts);
    summary_stats.TotalDuration(i) = sum(T_workouts.Duration);
    summary_stats.AvgDuration(i) = mean(T_workouts.Duration);
    summary_stats.AvgIntensity(i) = mean(T_workouts.Intensity);
    summary_stats.StdDevIntensity(i) = std(T_workouts.Intensity); % Consistency Metric
    summary_stats.AvgPostHR(i) = mean(T_workouts.PostWorkoutHR);
    summary_stats.AvgRecoveryRate(i) = mean(T_workouts.RecoveryRate);

end

disp(' ');
disp('Analysis Complete. Summary Statistics:');
disp(summary_stats);
disp(' ');

%% 5. DATA EXPORT
summary_filename = fullfile(RESULTS_FOLDER, 'summary_stats.csv');
writetable(summary_stats, summary_filename, 'WriteRowNames', true);
disp(['Summary table saved to: ', summary_filename]);

%% 6. VISUALIZATIONS
disp('Generating visualizations...');
athlete_colors = [0 0.4470 0.7410; 0.8500 0.3250 0.0980; 0.4660 0.6740 0.1880];

% Figure 1: HR Zone Minutes Comparison (Bar Chart)
figure('Name', 'HR Zone Minutes Comparison');
bar(all_zone_minutes, 'grouped');
title('Figure 1: Total Minutes Spent in Each Heart Rate Zone (21 Days)');
ylabel('Total Minutes');
set(gca, 'XTickLabel', HR_ZONES);
legend(ATHLETE_NAMES, 'Location', 'NorthWest');
grid on;
saveas(gcf, fullfile(RESULTS_FOLDER, 'zone_minutes_bar.png'));

% Figure 2: Daily Mean Heart Rate Trend (Line Plot)
figure('Name', 'Daily Mean Heart Rate Trend');
hold on;
title('Figure 2: Daily Post-Workout Heart Rate Over 21 Days');
xlabel('Day Number');
ylabel('Post-Workout Heart Rate (bpm)');
for i = 1:length(AthleteData)
    T = AthleteData{i};
    plot(T.Day, T.PostWorkoutHR, 'LineWidth', 2, 'Color', athlete_colors(i,:), 'Marker', 'o', 'MarkerSize', 5);
end
legend(ATHLETE_NAMES, 'Location', 'SouthEast');
grid on;
hold off;
saveas(gcf, fullfile(RESULTS_FOLDER, 'hr_trend_line.png'));

% Figure 3: Mean Recovery Rate Comparison
figure('Name', 'Recovery Rate Comparison');
bar(summary_stats.AvgRecoveryRate);
set(gca, 'XTickLabel', ATHLETE_NAMES);
title('Figure 3: Average Heart Rate Recovery Rate (PostHR - PreHR)');
ylabel('Average HR Difference (bpm)');
grid on;
saveas(gcf, fullfile(RESULTS_FOLDER, 'recovery_rate_bar.png'));

% Figure 4: Workout Duration Distribution
figure('Name', 'Workout Duration Distribution', 'Position', [100 100 900 300]);
sgtitle('Figure 4: Distribution of Workout Durations');
for i = 1:length(AthleteData)
    T_workouts = AthleteData{i};
    T_workouts = T_workouts(T_workouts.Duration > 0, :);
    subplot(1, 3, i);
    histogram(T_workouts.Duration, 'FaceColor', athlete_colors(i,:));
    title([ATHLETE_NAMES{i}, ' Athlete']);
    xlabel('Duration (minutes)');
    ylabel('Frequency');
end
saveas(gcf, fullfile(RESULTS_FOLDER, 'duration_distribution_hist.png'));

% Figure 5: Summary Dashboard (2x2 Subplots)
figure('Name', 'Summary Dashboard', 'Position', [100 100 900 600]);
sgtitle('Figure 5: Comparative Performance Dashboard (2x2)');

% Subplot 1: Total Workout Time
subplot(2, 2, 1);
bar(summary_stats.TotalDuration, 'FaceColor', [0.7 0.2 0.2]);
set(gca, 'XTickLabel', ATHLETE_NAMES);
title('Total Workout Duration (Minutes)');

% Subplot 2: Average Intensity
subplot(2, 2, 2);
bar(summary_stats.AvgIntensity, 'FaceColor', [0.2 0.7 0.2]);
set(gca, 'XTickLabel', ATHLETE_NAMES);
title('Average Self-Rated Intensity (1-10)');

% Subplot 3: Total Workouts Completed
subplot(2, 2, 3);
bar(summary_stats.TotalWorkouts, 'FaceColor', [0.2 0.2 0.7]);
set(gca, 'XTickLabel', ATHLETE_NAMES);
title('Total Workouts Completed (Count)');

% Subplot 4: Intensity Consistency (Std Dev)
subplot(2, 2, 4);
bar(summary_stats.StdDevIntensity, 'FaceColor', [0.8 0.5 0.1]);
set(gca, 'XTickLabel', ATHLETE_NAMES);
title('Intensity Consistency (Lower Std Dev is Better)');

saveas(gcf, fullfile(RESULTS_FOLDER, 'summary_dashboard.png'));
disp('*** All visualizations saved to the /Results folder. ***');

%% 7. WORKSPACE SAVE
save(fullfile(RESULTS_FOLDER, 'project_workspace.mat'), 'AthleteData', 'summary_stats', 'all_zone_minutes');
disp('Workspace saved successfully.');


%==========================================================================
% HELPER FUNCTION: process_athlete_data
% PURPOSE: Calculates Recovery Rate and assigns HR Zone based on PostWorkoutHR.
%==========================================================================
function T_processed = process_athlete_data(T_raw)
    % Calculate Recovery Rate
    T_raw.RecoveryRate = T_raw.PostWorkoutHR - T_raw.PreWorkoutHR;

    % Initialize categorical array for HR Zones
    T_raw.HRZone = categorical(zeros(height(T_raw), 1), 1:4, {'Resting', 'Light', 'Moderate', 'Vigorous'});

    % Implement CORRECT HR Zone Logic using PostWorkoutHR
    % The zones must be assigned in order (highest to lowest) to ensure correct categorization

    % VIGOROUS Zone: > 160 bpm
    idx_vigorous = T_raw.PostWorkoutHR > 160;
    T_raw.HRZone(idx_vigorous) = 'Vigorous';

    % MODERATE Zone: 130-160 bpm
    idx_moderate = (T_raw.PostWorkoutHR >= 130) & (T_raw.PostWorkoutHR <= 160);
    T_raw.HRZone(idx_moderate) = 'Moderate';

    % LIGHT Zone: 100-130 bpm
    idx_light = (T_raw.PostWorkoutHR >= 100) & (T_raw.PostWorkoutHR < 130);
    T_raw.HRZone(idx_light) = 'Light';

    % RESTING/Low Activity Zone: <= 100 bpm
    idx_resting = T_raw.PostWorkoutHR <= 100;
    T_raw.HRZone(idx_resting) = 'Resting';

    T_processed = T_raw;
end